from datetime import timedelta,datetime
#from django.utils.timezone import localtime
print(datetime.now().time()-timedelta(hours=5))